import{a as e}from"./bootstrap-D-W5kogu.js";const a=e("x",[["path",{d:"M18 6 6 18",key:"1bl5f8"}],["path",{d:"m6 6 12 12",key:"d8bk6v"}]]);export{a as X};
